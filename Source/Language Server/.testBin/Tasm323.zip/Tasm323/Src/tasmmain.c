/****************************************************************************
 *  $Id: tasmmain.c,v 3.1 2003/04/20 22:57:47 Tom Exp $
 ****************************************************************************
 *  File: tasmmain.c
 *
 * Table Driven Absolute Assembler.
 *
 *
 *    Copyright 1985-1995  Thomas N. Anderson, Speech Technology Incorporated.
 *    Copyright 1997-2003  Thomas N. Anderson, Squak Valley Software
 *    Restrictions apply to the duplication of this software.
 *    See the Copyright.txt file on this disk for restrictions.
 *
 *    Thomas N. Anderson
 *    Squak Valley Software
 *    837 Front Street South
 *    Issaquah, WA  98027
 *
 *  See rlog for revision history.
 *
 *
 */

static char *id_tasmmain_c = "$Id: tasmmain.c,v 3.1 2003/04/20 22:57:47 Tom Exp $";

#include "tasm.h"
#include <setjmp.h>

static jmp_buf Jump_buffer;    /* State information from return point */


/*
 *  This is just a top level main() to call the tasm() function
 *  which does all the work.  main was seperated from tasm() so 
 *  that tasm() can be called by the WinMain for the windows version.
 *
 */

void
main(int argc, char *argv[])
{
    int	exit_code;

    /* Setup the jump buffer for fatal exits */

    exit_code = setjmp ( Jump_buffer );
    if ( exit_code ) {
        /* A longjmp has occurred.  A fatal error must have been encountered */
        exit ( exit_code );
    
    }

    /* Pass all the args just as received. */
    exit_code = tasm (argc, argv);


    exit(exit_code);
    
}

void
tasmexit ( int exit_code )
{

    free_all();
    longjmp ( Jump_buffer, exit_code );

}
