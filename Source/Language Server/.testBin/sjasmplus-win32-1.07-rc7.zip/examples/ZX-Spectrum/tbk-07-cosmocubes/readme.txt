CosmoCubes 1k intro
(C)2007 triebkraft, psndcj
 
See more at:
http://www.pouet.net/prod.php?which=30100

platform : ZX Spectrum
type :	1k
release date :	march 2007
release party :	Forever 2007
compo :	zx 1k