
See "documentation" directory for the documentation of SjASMPlus.
To compile under Linux, FreeBSD etc you must download sources of SjASMPlus and use included Makefile.
